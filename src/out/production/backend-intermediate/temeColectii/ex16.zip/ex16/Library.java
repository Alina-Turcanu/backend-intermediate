package temeColectii.ex16;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Library implements Comparator <Book> {
    // //Librăria va trebui să conțină o colecție de cărți.
    //    // Fiecare carte are atributele: year, title, genre (gen) și author.
    //    //
    //    //Librăria va trebui să implementeze următoarele funcționalități:
    //    //
    //    //Afișarea cărților ordonate după year
    //    //Afișarea cărților ordonate după autor
    //    //Gruparea cărților după genre
    //    //Afișarea tuturor cărților dintr-un anumit gen
    //    //Afișarea tuturor genurilor împreună cu toate cărțile din fiecare gen
    //    //Afișarea tuturor genurilor
    //    //Adăugarea unei cărți
    //    //Ștergerea unei cărți
    public List<Book> books;

    public Library() {
        this.books = new ArrayList<>();
    }
        public void sortBooksByYear() {

        }

    @Override
    public int compare(Book b1, Book b2) {
        return Integer.valueOf(b1.getYear()).compareTo(Integer.valueOf(b2.getYear()));
    }

    public String compare(Book b1,Book b2){
        return String.valueOf(b1.getAuthor()).compareTo(String.valueOf(b2.getAuthor()));
    }
    public String compare (Book b1,Book b2){
        return String.valueOf(Integer.valueOf(b1.getGenre()).compareTo(String.valueOf(b2.getGenre())));
    }
}

