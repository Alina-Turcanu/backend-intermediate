package temeColectii.ex16;

import java.awt.print.Book;

public class Main {
    public static void main(String[] args) {
        Book book1=new Book();
    }
}
